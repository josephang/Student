package problemtwo;
import java.util.Scanner;

public class ProblemTwo {

    
    static double original, value = 1; 
    public static void main(String[] args){
        
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a value n of which to find the Harmonic Value for.");
        original  = input.nextDouble();
        
        Harmonic(original, value);
    }
    
    public static void Harmonic(double counter, double n){
        double c;
        if(counter > 1){
        c = 1 / counter;
        n = n + c;
        counter--;
        Harmonic(counter,n);
        }
        else{
           
            System.out.println("The Harmonic Number of " + original + " is " + n);
        }
    }
}
