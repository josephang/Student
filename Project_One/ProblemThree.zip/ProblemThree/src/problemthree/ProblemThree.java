package problemthree;
public class ProblemThree {
    public int addList(List aList){
        int size = 0, sum = 0;
         
        while(size < aList.size()){
            
            sum = sum + aList.get[size];
            size++;
        }
        
        return sum;
    }
}
