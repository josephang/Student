package problemone;

import java.util.Scanner;

public class ProblemOne {
    static double originalp2, counterp2 = 1, powerp2;
    
    public static void main(String[] args){
        double term, power;
            Scanner input = new Scanner(System.in);
            System.out.println("Please enter a value for x");
            term  = input.nextDouble();
            originalp2 = term;
            System.out.println("Please enter a value for n where n is a power of x");
            power = input.nextDouble();
            powerp2 = power;
            power1(term, power);
            power2(term);
    
}
    public static void power1( double x, double power){
        int counter = 1; 
        boolean iterate = true;
        double originalp1 = x;
        if(power > 0){
             while( iterate == true ){
                 x = x * originalp1;
                 counter = counter +1;
                 
                     if(counter == power){
                         iterate = false;
                    }
            
                }
            }
        if(power == 0){
            x = 1;
        }    
    System.out.println("Using an iterative loop, the value of " + originalp2 + " to the " + power + "th power is " + x);
        
    }
    
    public static void power2(double x){
        if(counterp2 < powerp2 && counterp2 != -1){
            x = x * originalp2;
            counterp2++;
            power2(x);
        }
        if(counterp2 == powerp2){
            System.out.println("Using recursion, the value of " + originalp2 + " to the " + powerp2 + "th power is " + x);
            counterp2 = 0;
        }
    }
}
